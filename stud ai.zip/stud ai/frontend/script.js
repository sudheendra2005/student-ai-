// frontend/script.js - Upgraded Version

const chatBox = document.getElementById('chat-box');
const userInput = document.getElementById('user-input');
const API_URL = 'http://127.0.0.1:5000/api/chat'; 

async function sendMessage() {
    const message = userInput.value.trim();
    if (message === "") return;

    // 1. Display User Message & Clear Input
    appendMessage('You', message, 'user-message');
    userInput.value = '';
    userInput.disabled = true; // Disable input while waiting for AI

    // 2. Display 'Typing...' Indicator
    const aiTypingId = appendMessage('AI', 'Typing...', 'ai-message');
    
    // 3. Send to Python Backend
    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ message: message })
        });
        
        // CHECK 1: Ensure the HTTP response itself was successful (status 200)
        if (!response.ok) {
            // If the server responded with an error status (e.g., 404, 500)
            const errorData = await response.json();
            throw new Error(errorData.error || `Server responded with status: ${response.status}`);
        }

        // Proceed to process JSON data
        const data = await response.json();
        const aiResponse = data.response || "Sorry, an unknown error occurred.";

        // 4. Update Chat Box with AI Response
        updateMessage(aiTypingId, aiResponse);
        
    } catch (error) {
        // This catches network errors OR errors thrown from the response.ok check above
        console.error('Error fetching AI response:', error);
        
        let displayError = 'Error: Could not connect to the AI companion server.';
        if (error.message.includes("Server responded")) {
             displayError = `Server Error: ${error.message}`;
        }
        
        updateMessage(aiTypingId, displayError);
        
    } finally {
        // Re-enable input regardless of success or failure
        userInput.disabled = false; 
        userInput.focus(); // Focus back to the input field
    }
}

function appendMessage(sender, text, className) {
    const messageElement = document.createElement('p');
    messageElement.classList.add(className);
    // Use innerHTML only for strong tag, then create a text node for safety
    messageElement.innerHTML = `<strong>${sender}:</strong> `;
    messageElement.appendChild(document.createTextNode(text));
    
    chatBox.appendChild(messageElement);
    chatBox.scrollTop = chatBox.scrollHeight;
    
    // Assign a temporary ID for updating 'Typing...' message
    const tempId = Date.now();
    messageElement.id = `msg-${tempId}`;
    return `msg-${tempId}`;
}

function updateMessage(id, newText) {
    const element = document.getElementById(id);
    if (element) {
        // Simple update: assumes the element structure is <strong>...</strong> Text
        element.innerHTML = `<strong>AI:</strong> ${newText}`;
    }
}

// Allow sending message with the Enter key
userInput.addEventListener('keypress', function (e) {
    if (e.key === 'Enter') {
        sendMessage();
    }
});