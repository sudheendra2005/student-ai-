# backend/app.py - Final Corrected Standalone Version

import os
from dotenv import load_dotenv
from flask import Flask, request, jsonify
from flask_cors import CORS 
# Only importing the necessary modules for the simple chat
from google import genai 
from datetime import timedelta # Keep if your Flask app config uses it, but removing below as it's not needed for simple chat

# Load environment variables
load_dotenv() 

# --- CONFIGURATION & SETUP ---
# Fetch API Key from environment variables
API_KEY = os.getenv("GEMINI_API_KEY") or os.getenv("AI_API_KEY")

if not API_KEY:
    raise ValueError("FATAL ERROR: AI_API_KEY not found in .env file. Please check and restart.")

app = Flask(__name__)
# Enable CORS to allow your frontend (5500) to talk to the backend (5000)
CORS(app) 

# Initialize the Gemini Client
client = genai.Client(api_key=API_KEY)


# --- AI LOGIC ---

def get_ai_response(user_message):
    """
    Sends the user message to the Gemini 2.5 Flash model with a specific system instruction.
    """
    try:
        # Define the system instruction based on your zero-investment goal
        system_instruction = (
            "You are a friendly, helpful, and concise Student AI Companion named Sudhi's Helper. "
            "Your main focus is helping the user learn new skills to make money, concentrating on "
            "zero-investment, high-demand skills like digital marketing, coding, or freelancing. "
            "Always be encouraging and provide clear, actionable advice related to their goal."
        )
        
        # Call the Gemini API
        response = client.models.generate_content(
            model='gemini-2.5-flash',
            contents=[user_message],
            config={
                'system_instruction': system_instruction
            }
        )
        
        return response.text
        
    except Exception as e:
        # Error handling for AI connection issues
        print(f"--- Gemini API Error --- Full Error: {e} ------------------------")
        return "Sorry, I had trouble connecting to the AI brain. Please check your API key and network connection."


# --- API ROUTES ---

@app.route('/api/chat', methods=['POST'])
# NO @login_required DECORATOR HERE
def chat():
    """Handles the chat message and returns AI response."""
    try:
        data = request.get_json()
        user_message = data.get('message', '')
        
        if not user_message:
            return jsonify({'error': 'No message provided'}), 400
        
        ai_response = get_ai_response(user_message)
        
        return jsonify({'response': ai_response})

    except Exception as e:
        # General server error handling
        return jsonify({'error': str(e)}), 500


# --- START THE SERVER ---
if __name__ == '__main__':
    port = os.getenv("FLASK_RUN_PORT", 5000) 
    print(f"Flask server running on http://127.0.0.1:{port}")
    app.run(debug=True, port=port)